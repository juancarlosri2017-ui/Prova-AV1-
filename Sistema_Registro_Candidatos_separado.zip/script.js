let candidatosData = [];

fetch('candidatos.json')
    .then(response => response.json())
    .then(data => {
        candidatosData = data;
        inicializarSistema();
    })
    .catch(error => console.error('Erro ao carregar candidatos.json:', error));

function inicializarSistema() {
// Dados de Simulação do Partido PDisney (91)
        
        // Regras por Cargo Eletivo para PDisney (91)
        const CARGO_RULES = {
            "Presidente": { max: 1, digits: 2, prefix: "91" },
            "Governador": { max: 1, digits: 3, prefix: "91" },
            "Senador": { max: 2, digits: 4, prefix: "91" },
            "Deputado Federal": { max: Infinity, digits: 5, prefix: "91" },
            "Deputado Estadual": { max: Infinity, digits: 6, prefix: "91" }
        };

        // Estado da Aplicação
        let filiadosPDisney = [];
        let chapaOficial = [];

        // Inicialização
        document.addEventListener("DOMContentLoaded", () => {
            carregarEFiltrarDados();
            setupEventListeners();
        });

        // Step 1 & 2: Leitura, Carga dos Dados e Filtragem
        function carregarEFiltrarDados() {
            // Filtra rigorosamente por PDisney / Número 91
            filiadosPDisney = candidatosData.filter(c => c.partido === "PDisney" || c.numeroPartido === 91);
            renderFiliados();
            updateSelectOptions();
        }

        // Renderiza lista de filiados no painel visual
        function renderFiliados() {
            const listEl = document.getElementById("filiadosList");
            const countEl = document.getElementById("filiadosCount");
            
            listEl.innerHTML = "";
            countEl.textContent = `(${filiadosPDisney.length} cadastrados)`;

            filiadosPDisney.forEach(filiado => {
                const isAssigned = chapaOficial.some(c => c.id === filiado.id);
                const card = document.createElement("div");
                card.className = `candidate-card ${isAssigned ? 'assigned' : ''}`;
                card.innerHTML = `
                    <img src="${filiado.foto}" alt="${filiado.nome}">
                    <div class="candidate-info">
                        <h4>${filiado.nome}</h4>
                        <p>${isAssigned ? '✓ Já indicado' : 'Disponível'}</p>
                    </div>
                `;
                listEl.appendChild(card);
            });
        }

        // Atualiza a combo de seleção de filiados
        function updateSelectOptions() {
            const selectEl = document.getElementById("filiadoSelect");
            selectEl.innerHTML = '<option value="">Selecione um filiado...</option>';

            filiadosPDisney.forEach(filiado => {
                const isAssigned = chapaOficial.some(c => c.id === filiado.id);
                if (!isAssigned) {
                    const opt = document.createElement("option");
                    opt.value = filiado.id;
                    opt.textContent = filiado.nome;
                    selectEl.appendChild(opt);
                }
            });
        }

        // Configuração de Eventos
        function setupEventListeners() {
            document.getElementById("cargoSelect").addEventListener("change", handleCargoChange);
            document.getElementById("nominationForm").addEventListener("submit", handleAddCandidate);
            document.getElementById("downloadBtn").addEventListener("click", handleDownload);
        }

        function handleCargoChange(e) {
            const cargo = e.target.value;
            const hintEl = document.getElementById("numeroHint");
            if (cargo && CARGO_RULES[cargo]) {
                const rule = CARGO_RULES[cargo];
                hintEl.textContent = `Regra: Deve começar com '91' e ter exatamente ${rule.digits} dígitos.`;
            } else {
                hintEl.textContent = "Selecione o cargo para ver as regras de formato do número.";
            }
        }

        // Step 3: Seleção e Validação
        function handleAddCandidate(e) {
            e.preventDefault();
            showAlert("", false);

            const filiadoId = parseInt(document.getElementById("filiadoSelect").value);
            const cargo = document.getElementById("cargoSelect").value;
            const numero = document.getElementById("numeroInput").value.trim();

            if (!filiadoId || !cargo || !numero) {
                showAlert("Por favor, preencha todos os campos do formulário.", true);
                return;
            }

            // 1. Validação de Candidatura Única
            const jaIndicado = chapaOficial.some(c => c.id === filiadoId);
            if (jaIndicado) {
                showAlert("Este filiado já foi indicado para outro cargo eletivo!", true);
                return;
            }

            // 2. Validação do Limite de Vagas
            const rule = CARGO_RULES[cargo];
            const indicadosParaCargo = chapaOficial.filter(c => c.cargo === cargo).length;
            if (indicadosParaCargo >= rule.max) {
                showAlert(`Limite de vagas atingido para o cargo de ${cargo} (Máximo: ${rule.max}).`, true);
                return;
            }

            // 3. Validação do Número Eleitoral
            const regexDígitos = new RegExp(`^91\\d{${rule.digits - 2}}$`);
            if (rule.digits === 2 && numero !== "91") {
                showAlert(`Para o cargo de ${cargo}, o número deve ser exatamente '91'.`, true);
                return;
            } else if (rule.digits > 2 && !regexDígitos.test(numero)) {
                showAlert(`Número inválido para ${cargo}. Deve iniciar com 91 e conter exatamente ${rule.digits} dígitos (Ex: 91${"0".repeat(rule.digits - 2)}).`, true);
                return;
            }

            // 4. Validação de Número Duplicado na Chapa
            const numeroExiste = chapaOficial.some(c => c.numero === numero);
            if (numeroExiste) {
                showAlert("Este número eleitoral já foi atribuído a outro candidato da chapa.", true);
                return;
            }

            // Atribuição com sucesso
            const filiado = filiadosPDisney.find(f => f.id === filiadoId);
            chapaOficial.push({
                id: filiado.id,
                nome: filiado.nome,
                cargo: cargo,
                numero: numero,
                foto: filiado.foto
            });

            // Reset do formulário e atualizar views
            document.getElementById("nominationForm").reset();
            document.getElementById("numeroHint").textContent = "Selecione o cargo para ver as regras de formato do número.";
            showAlert(`Candidato(a) ${filiado.nome} adicionado(a) com sucesso como ${cargo}!`, false);
            
            updateUI();
        }

        function removeCandidate(id) {
            chapaOficial = chapaOficial.filter(c => c.id !== id);
            showAlert("Candidato removido da chapa.", false);
            updateUI();
        }

        function updateUI() {
            renderFiliados();
            updateSelectOptions();
            renderChapaTable();
        }

        function renderChapaTable() {
            const tbody = document.getElementById("chapaTableBody");
            if (chapaOficial.length === 0) {
                tbody.innerHTML = '<tr><td colspan="5" style="text-align: center; color: #94a3b8;">Nenhum candidato indicado ainda.</td></tr>';
                return;
            }

            tbody.innerHTML = "";
            chapaOficial.forEach(c => {
                const tr = document.createElement("tr");
                tr.innerHTML = `
                    <td><img src="${c.foto}" alt="${c.nome}"></td>
                    <td><strong>${c.nome}</strong></td>
                    <td>${c.cargo}</td>
                    <td><code>${c.numero}</code></td>
                    <td><button class="btn-danger" style="padding: 4px 8px; font-size: 0.8rem;" onclick="removeCandidate(${c.id})">Remover</button></td>
                `;
                tbody.appendChild(tr);
            });
        }

        // Step 4: Geração e Download do Arquivo JSON (PDisney.json)
        function handleDownload() {
            if (chapaOficial.length === 0) {
                showAlert("Sua chapa está vazia. Adicione ao menos um candidato antes de gerar o arquivo final.", true);
                return;
            }

            // Formatação do JSON conforme requisitado: nome, numero, foto, cargo
            const dataToExport = chapaOficial.map(c => ({
                nome: c.nome,
                numero: c.numero,
                foto: c.foto,
                cargo: c.cargo
            }));

            const jsonString = JSON.stringify(dataToExport, null, 2);
            const blob = new Blob([jsonString], { type: "application/json" });
            const url = URL.createObjectURL(blob);

            const a = document.createElement("a");
            a.href = url;
            a.download = "PDisney.json";
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);

            showAlert("Download do arquivo PDisney.json realizado com sucesso!", false);
        }

        function showAlert(msg, isError) {
            const box = document.getElementById("alertBox");
            if (!msg) {
                box.style.display = "none";
                return;
            }
            box.className = `alert ${isError ? 'alert-error' : 'alert-success'}`;
            box.textContent = msg;
            box.style.display = "block";
        }

}
